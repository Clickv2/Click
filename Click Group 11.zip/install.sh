cd click-2.0.1
./configure --disable-linuxmodule --enable-local --enable-etherswitch
make -j2
cd ..
